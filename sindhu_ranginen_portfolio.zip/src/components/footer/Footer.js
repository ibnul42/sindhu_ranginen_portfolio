import React from 'react';

const Footer = () => {
    return (
        <div className="container fluid mt-4 mb-3" >
            <div className="row">
                <div className="col" >© 2021 All rights reserved by Sindhu Ranginen</div>
            </div>

        </div>
    );
};

export default Footer;